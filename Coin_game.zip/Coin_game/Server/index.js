const express = require('express');
const mongoose = require('mongoose');
const UserModel  = require('./model');
const cors = require('cors');


const app = express();
const port = 3001;

app.use(cors()); // You need to invoke cors as a function
app.use(express.json());
app.use(express.urlencoded({extended:false}));

mongoose.connect('mongodb://127.0.0.1:27017', { useNewUrlParser: true, useUnifiedTopology: true }) // You need to specify a database name and provide additional options
  .then(() => {
    console.log("Mongoose Database connected");
  })
  .catch((err) => {
    console.log(err);
  });

app.get('/find', async (req, res) => {
  try {
          let result;
           UserModel.find({'username' : req.body.username}).then(result=true)
    res.json(result);
  } catch (err) {
    console.log(err);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});


app.post('/add',async (req, res) => {
          try {
            const result = await UserModel.create(req.body);
            res.json(result);
          } catch (err) {
            console.log(err);
            res.status(500).json({ error: 'Internal Server Error' });
          }
        });
        


app.listen(port, () => {
  console.log("Server Created..!!");
});
