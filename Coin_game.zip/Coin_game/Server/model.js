const mongoose=require('mongoose');
const schema=mongoose.Schema({
          username:String,
          password:String,
          match_played:Number,
          score:Array,
});
const UserModel=mongoose.model('coin_game',schema);
module.exports=UserModel;