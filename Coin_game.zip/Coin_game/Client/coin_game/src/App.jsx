
import {BrowserRouter, Route, Routes} from 'react-router-dom';
import './App.css'
import { Login_page } from './Component/Login_page';
import { Registration_page } from './Component/Registration_page';
import { Game_play } from './Component/Game_play';


function App() {
  return (
    <BrowserRouter >
    <Routes>
      <Route path='/' element={<Login_page/>} ></Route>
      <Route path='/registration' element={<Registration_page/>}></Route>
      <Route path='/Home' element={<Game_play/>}></Route>
    </Routes>
    
    </BrowserRouter>
  )
}

export default App
