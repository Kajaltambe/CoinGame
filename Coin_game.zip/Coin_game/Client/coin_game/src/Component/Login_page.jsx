import React, { useState } from 'react'
import './Login_page_CSS.css'
import { Link } from 'react-router-dom'
import {useNavigate} from 'react-router-dom'
import axios from'axios'
export const Login_page = () => {
          const navigate = useNavigate();
          const[username,setusername]=useState();
          const[pass,setpass]=useState();
          
          function login(e){
                    e.preventDefault();
                    axios.get('http://localhost:3001/find',{username:username,password:pass}).then((res)=>{
                    if(res.data)          
                    navigate('/Home');
                    else console.log("not found..!! register please...");
                    }).catch((err)=>{console.log(err);});

          }
  return (
    < div className='body_'>
    <div className='image_div'> </div>
                    <div className='login_div'>
                    <h4>Login Account</h4>
                    <h1>Hello,</h1>
                    <h1 className='welcome_style'>Welcome</h1>
                    <form className="form_" >
                    <input placeholder="Enter user_id" value={username} onChange={(e)=>{setusername(e.target.value)}} type="text" name="userName"/>
                    <input placeholder="Enter Password"value={pass} onChange={(e)=>setpass(e.target.value)} type="password" name="userPass"/>
                    <input style={{width:'50%',height:'40px'}} type="submit" onClick={login} value="Login.." className="submit_value"/>
                    </form>
                    <Link to={'/registration'}>Click here to register</Link>
                    </div>

    </div>
  )
}
