import React, { useState } from 'react'
import './Login_page_CSS.css'
import { Link } from 'react-router-dom'
import {useNavigate} from 'react-router-dom'
import axios from'axios'

export const Registration_page = () => {
          const navigate = useNavigate();
          const[username,setusername]=useState();
          const[pass,setpass]=useState();
          
          function register(e){
                    e.preventDefault();
                    axios.post('http://localhost:3001/add',{username:username,password:pass}).then((res)=>{          
                    navigate('/');
                    }).catch((err)=>{console.log(err);});

          }
  return (
          < div className='body_'>
          <div className='image_div'> </div>
                          <div className='login_div'>
                          <h4>Register Account</h4>
                          <h1>Hello,</h1>
                          <h1 className='welcome_style'>Welcome Register your self</h1>
                          <form className="form_" >
                          <input placeholder="Enter user_id" value={username} onChange={(e)=>{setusername(e.target.value)}} type="text" name="userName"/>
                          <input placeholder="Enter Password"value={pass} onChange={(e)=>setpass(e.target.value)} type="password" name="userPass"/>
                          <input style={{width:'50%',height:'40px'}} type="submit" onClick={register} value="Login.." className="submit_value"/>
                          </form>
      
                          </div>
      
          </div>
  )
}
