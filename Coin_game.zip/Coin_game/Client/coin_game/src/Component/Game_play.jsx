import React from 'react'
import { useEffect, useState } from 'react'
import coin_image from '../assets/coin.png'
import './Game_play_CSS.css'
export const Game_play = () => {
          const[starcount,setstarCount]=useState(21);
          const[ai_count,set_aiCount]=useState(0);
          const[result,setresult]=useState("");
          useEffect(()=>{
            if(starcount==1)setresult("loose");
          });
          
        function after_user_select(user_choice){
            let star=starcount-user_choice;
            let x=0;
            if(star<2)setresult("win");
            else if(star<3)x=Math.floor(Math.random() * (2 - 1) + 1);
            else if(star<4)x=Math.floor(Math.random() * (3 - 1) + 1);
            else x=Math.floor(Math.random() * (5 - 1) + 1);
            set_aiCount(x);
            setstarCount(star-x);
        }
          return (
            <>
            <center><h1>Coin Game</h1><hr /></center>
            <h2>This is a coin game you need to choose any number of coin and then I also choose.whom so ever remain at end to choice at last will lose this game .. Let's see who win this game</h2>
            <hr /><div className='display_star'>
            {Array.from({ length: starcount }, (_, i) => <span key={i}>
              <img src={coin_image} width={80} height={80} />
            </span>)}
            </div>
            <hr />
            <center><h2>Select number of coin you want to remove..!!</h2></center>
            <h3>Ai Selected Number Of Coin is={ai_count}</h3>
            <div  className='button_choice'>
              <button onClick={()=>{after_user_select(1)}}>1</button>
              {(starcount>2)?
              <button onClick={()=>{after_user_select(2)}}>2</button>:""}
              {(starcount>3)?
              <button onClick={()=>{after_user_select(3)}}>3</button>:""}
              {(starcount>4)?
              <button onClick={()=>{after_user_select(4)}}>4</button>:""}
            </div>
             <h1>{result}</h1>
            </>
          )
        }
